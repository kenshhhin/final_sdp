import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.UUID;

public class Main {
    private DatabaseManager database = DatabaseManager.getInstance();
    private Scanner scanner = new Scanner(System.in);

    private Map<Integer, Dish> cart = new HashMap<>();
    private OrderSubject orderSubject = new OrderStatusSubject();
    private OrderDecorator orderDecorator;
    private KaspiBank userKaspiBankInfo;

    public void start() {
        System.out.println(" ");

        while (true) {
            System.out.println("\n1. Restaurants\n2. Order\n3. Help\n0. Exit");
            System.out.println(" ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline

            switch (choice) {
                case 1:
                    showRestaurants();
                    break;
                case 2:
                    placeOrder(orderDecorator);
                    break;
                case 3:
                    System.out.println("If you encounter difficulties or want to contact us : lalalala@mail.com");
                    break;
                case 0:
                    System.out.println("Exiting. Goodbye!");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private void showRestaurants() {
        try {
            Connection connection = database.getConnection();
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM restaurants");

            System.out.println(" ");
            System.out.println("Restaurants:");
            while (resultSet.next()) {
                int restaurantId = resultSet.getInt("restaurant_id");
                String restaurantName = resultSet.getString("restaurant_name");
                System.out.println(restaurantId + "." + restaurantName);
            }

            System.out.println(" ");
            System.out.println("Choose restaurant (Enter ID) or 0 to return:");
            int chosenRestaurantId = scanner.nextInt();
            scanner.nextLine(); // Consume the newline

            // Check if the chosen ID is valid
            if (isValidRestaurantId(chosenRestaurantId)) {
                // Fetch and display menu or information about the selected restaurant
                displayRestaurantOptions(chosenRestaurantId);
            }
            else if (chosenRestaurantId == 0) {
                start();
            }
            else {
                System.out.println("Invalid restaurant selection.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private boolean isValidRestaurantId(int restaurantId) {
        try {
            Connection connection = database.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM restaurants WHERE restaurant_id = ?");
            preparedStatement.setInt(1, restaurantId);
            ResultSet resultSet = preparedStatement.executeQuery();

            return resultSet.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private void displayRestaurantOptions(int chosenRestaurantId) {
        while (true) {
            System.out.println("\n1. Menu\n2. Info\n0. Back to Restaurants");
            System.out.println(" ");
            int option = scanner.nextInt();
            scanner.nextLine(); // Consume the newline

            switch (option) {
                case 1:
                    displayMenu(chosenRestaurantId);
                    break;
                case 2:
                    displayRestaurantInfo(chosenRestaurantId);
                    break;
                case 0:
                    showRestaurants();
                    return; // Return to exit the loop
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private void displayMenu(int chosenRestaurantId) {
        try {
            Connection connection = database.getConnection();

            // Fetch menu for the selected restaurant using restaurant_id
            PreparedStatement menuStatement = connection.prepareStatement("SELECT * FROM " + "menu_" + chosenRestaurantId );
            ResultSet menuResultSet = menuStatement.executeQuery();

            System.out.println(" ");
            while (menuResultSet.next()) {
                int dishId = menuResultSet.getInt("dish_id");
                String dishName = menuResultSet.getString("dish_name");
                double dishPrice = menuResultSet.getDouble("dish_price");

                System.out.println(dishId + " | " + dishName + " | " + dishPrice);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        processCart(chosenRestaurantId, orderDecorator);
    }

    private void displayRestaurantInfo(int chosenRestaurantId) {
        // Fetch and display information about the selected restaurant
        Restaurant restaurant = fetchRestaurantDetails(chosenRestaurantId);

        if (restaurant != null) {
            System.out.println(restaurant);
        }
    }

    private Restaurant fetchRestaurantDetails(int chosenRestaurantId) {
        try {
            Connection connection = database.getConnection();
            PreparedStatement restaurantStatement = connection.prepareStatement("SELECT * FROM restaurants WHERE restaurant_id = ?");
            restaurantStatement.setInt(1, chosenRestaurantId);
            ResultSet restaurantResultSet = restaurantStatement.executeQuery();

            if (restaurantResultSet.next()) {
                System.out.println(" ");
                return new Restaurant(
                        chosenRestaurantId,
                        restaurantResultSet.getString("restaurant_name"),
                        restaurantResultSet.getString("address"),
                        restaurantResultSet.getString("contacts"),
                        restaurantResultSet.getString("website"),
                        restaurantResultSet.getDouble("rating")
                );
            } else {
                System.out.println("Invalid restaurant selection.");
                return null;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    private void addToCart(int chosenRestaurantId, int dishId, int quantity) {
        try {
            Connection connection = database.getConnection();
            PreparedStatement dishStatement = connection.prepareStatement("SELECT * FROM menu_" + chosenRestaurantId + " WHERE dish_id = ?");
            dishStatement.setInt(1, dishId);
            ResultSet dishResultSet = dishStatement.executeQuery();

            if (dishResultSet.next()) {
                PricingStrategy pricingStrategy = new RegularPricingStrategy(); // Initialize with a default strategy
                Dish dish = new Dish(
                        dishId,
                        dishResultSet.getString("dish_name"),
                        dishResultSet.getDouble("dish_price"),
                        pricingStrategy,
                        orderDecorator
                );

                // Update quantity in the Dish object
                dish.setQuantity(quantity);

                cart.put(dishId, dish);
                System.out.println("Added to cart: " + quantity + " x " + dish.getDishName() + " | " + dish.getDishPrice());
            } else {
                System.out.println("Dish with ID " + dishId + " not found.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    private void removeFromCart(int dishId, int quantity) {
        if (cart.containsKey(dishId)) {
            Dish dish = cart.get(dishId);

            if (quantity >= dish.getQuantity()) {
                cart.remove(dishId);
                System.out.println("Removed from cart: " + dish.getDishName() + " | " + dish.getDishPrice());
            } else {
                dish.setQuantity(dish.getQuantity() - quantity);
                System.out.println("Removed from cart: " + dish.getQuantity() + " x " + dish.getDishName() + " | " + dish.getDishPrice());
            }
        } else {
            System.out.println("Dish with ID " + dishId + " not found in the cart.");
        }
    }

    private void viewCart(int chosenRestaurantId, OrderDecorator orderDecorator) {
        System.out.println(" ");
        System.out.println("Cart Contents:");
        if (cart.isEmpty()) {
            System.out.println("Your cart is empty.");
        } else {
            for (Map.Entry<Integer, Dish> entry : cart.entrySet()) {
                Dish dish = entry.getValue();
                System.out.println(dish.getDishName() + " | " + dish.getDishPrice() + " - " + dish.getQuantity() + " x");
            }
        }
        System.out.println("\n1. Confirm Order\n2. Cancel");
        int confirmation = scanner.nextInt();
        scanner.nextLine(); // Consume the newline

        if (confirmation == 1) {
            placeOrder(orderDecorator);
        } else {
            displayRestaurantOptions(chosenRestaurantId);
        }
    }

    private void processCart(int chosenRestaurantId, OrderDecorator orderDecorator) {
        while (true) {
            System.out.println("\n1. Add to Cart\n2. Remove from Cart\n3. View Cart\n4. Return");
            int option = scanner.nextInt();
            scanner.nextLine(); // Consume the newline

            switch (option) {
                case 1:
                    addToCartOption(chosenRestaurantId);
                    break;
                case 2:
                    removeFromCartOption(chosenRestaurantId);
                    break;
                case 3:
                    viewCart(chosenRestaurantId, orderDecorator);
                    break;
                case 0:
                    displayRestaurantOptions(chosenRestaurantId);
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private void addToCartOption(int chosenRestaurantId) {
        int dishId = promptForDishId(chosenRestaurantId);

        if (dishId != 0) {
            int quantity = promptForQuantity();

            if (quantity != 0) {
                addToCart(chosenRestaurantId, dishId, quantity);
            } else {
                System.out.println("Canceled adding to cart.");
            }
        } else {
            System.out.println("Canceled adding to cart.");
        }
    }

    private int promptForDishId(int chosenRestaurantId) {
        System.out.println("Enter Dish ID to add to cart or 0 to cancel:");
        return scanner.nextInt();
    }

    private int promptForQuantity() {
        System.out.println("Enter quantity or 0 to cancel:");
        return scanner.nextInt();
    }

    private void removeFromCartOption(int chosenRestaurantId) {
        System.out.println("Enter Dish ID to remove from cart:");
        int dishId = scanner.nextInt();
        scanner.nextLine(); // Consume the newline
        if(dishId==0) {
            processCart(chosenRestaurantId, orderDecorator);
        }

        System.out.println("Enter quantity:");
        int quantity = scanner.nextInt();
        scanner.nextLine(); // Consume the newline
        if(dishId==0) {
            processCart(chosenRestaurantId, orderDecorator);
        }

        removeFromCart(dishId, quantity);
    }

    private void placeOrder(OrderDecorator orderDecorator) {
        // Generate a unique order ID (you may use a more robust method)
        String orderId = UUID.randomUUID().toString();

        // Notify observers (e.g., order status observer)
        orderSubject.notifyObservers("Order Placed");

        // Calculate the total price of the order
        double totalPrice = cart.values().stream().mapToDouble(Dish::getDishPrice).sum();

        // Get user's bank card information
        KaspiBank kaspiBank = getUserKaspiBankInfo();

        // Process payment using the adapter
        KaspiBankAdapter kaspiBankAdapter = new KaspiBankAdapter();
        processPayment(kaspiBankAdapter, totalPrice);


        // Process payment using the adapter
        PaymentAdapter paymentAdapter = new PaymentAdapter();
        paymentAdapter.processPayment(totalPrice);

        // Notify observers (e.g., order status observer)
        orderSubject.notifyObservers("Payment Processed");

        // Create an order using the Factory Method pattern
        OrderFactory orderFactory = getUserOrderType();
        Order order = orderFactory.createOrder(orderId);
        order.setDecorator(orderDecorator); // Apply the decorator
        order.placeOrder();


        // Clear the cart after successful payment
        cart.clear();
        System.out.println("Thank you for using our service!");
    }

    private void processPayment(PaymentGateway paymentGateway, double amount) {
        paymentGateway.processPayment(amount);
    }

    private OrderFactory getUserOrderType() {
        // Get user's order preference (Online or In-Person)
        System.out.println("\nSelect Order Type:");
        System.out.println("1. Online Order");
        System.out.println("2. In-Person Order");

        int orderTypeChoice = scanner.nextInt();
        scanner.nextLine(); // Consume the newline

        switch (orderTypeChoice) {
            case 1:
                return new BasicOrderFactory();
            case 2:
                return new InPersonOrderFactory();
            default:
                throw new IllegalArgumentException("Invalid order type choice.");
        }
    }

    public static void main(String[] args) {
        System.out.println(" ");
        System.out.println("Welcome to Online Food Delivery System!");
        Main system = new Main();
        system.start();
    }

    public KaspiBank getUserKaspiBankInfo() {
        return userKaspiBankInfo;
    }

    public void setUserKaspiBankInfo(KaspiBank userKaspiBankInfo) {
        this.userKaspiBankInfo = userKaspiBankInfo;
    }
}



