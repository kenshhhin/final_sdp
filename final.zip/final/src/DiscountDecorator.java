class DiscountDecorator implements OrderDecorator {
    private double discountPercentage;

    public DiscountDecorator(double discountPercentage) {
        this.discountPercentage = discountPercentage;
    }

    @Override
    public double decorate(double originalPrice) {
        return originalPrice * (1 - discountPercentage / 100);
    }
}