class OrderStatusObserver implements OrderObserver {
    private String orderId;

    public OrderStatusObserver(String orderId) {
        this.orderId = orderId;
    }

    @Override
    public void update(String orderStatus) {
        System.out.println("Order " + orderId + " status updated: " + orderStatus);
    }
}