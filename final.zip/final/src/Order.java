interface Order {
    void placeOrder();

    void setDecorator(OrderDecorator orderDecorator);
}
