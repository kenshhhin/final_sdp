public class OnlineOrder implements Order {
    private String orderId;

    public OnlineOrder(String orderId) {
        this.orderId = orderId;
    }

    @Override
    public void placeOrder() {
        // Implement the logic for placing an online order
        System.out.println("Online order placed. Order ID: " + orderId);
    }

    @Override
    public void setDecorator(OrderDecorator orderDecorator) {
        // Implement the logic for setting a decorator
        System.out.println("Decorator set for order " + orderId);
    }
}
