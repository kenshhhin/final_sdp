public class Dish {
    private final int dishId;
    private final String dishName;
    private final double dishPrice;
    private int quantity;
    private PricingStrategy pricingStrategy;
    private OrderDecorator orderDecorator;

    public Dish(int dishId, String dishName, double dishPrice, PricingStrategy pricingStrategy, OrderDecorator orderDecorator) {
        this.dishId = dishId;
        this.dishName = dishName;
        this.dishPrice = dishPrice;
        this.pricingStrategy = pricingStrategy;
        this.orderDecorator = orderDecorator;
    }

    public String getDishName() {
        return dishName;
    }

    public double getDishPrice() {
        // Check if pricingStrategy is not null before invoking calculatePrice
        if (pricingStrategy != null) {
            return pricingStrategy.calculatePrice(dishPrice);
        } else {
            // Handle the case where pricingStrategy is not set
            return dishPrice;
        }
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public PricingStrategy getPricingStrategy() {
        return pricingStrategy;
    }

    // Setter for updating the pricing strategy
    public void setPricingStrategy(PricingStrategy pricingStrategy) {
        this.pricingStrategy = pricingStrategy;
    }

    @Override
    public String toString() {
        return "Dish ID " + dishId + ": " + quantity + " x " + dishName + " - " + dishPrice;
    }
}
