interface OrderObserver {
    void update(String orderStatus);
}
