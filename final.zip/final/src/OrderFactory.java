interface OrderFactory {
    Order createOrder(String orderId);
}