class InPersonOrderFactory implements OrderFactory {
    @Override
    public Order createOrder(String orderId) {
        return new InPersonOrder(orderId);
    }
}
