class BasicOrderFactory implements OrderFactory {
    @Override
    public Order createOrder(String orderId) {
        return new OnlineOrder(orderId);
    }
}