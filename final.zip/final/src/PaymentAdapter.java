class PaymentAdapter {
    // Adapt an external payment gateway to the system
    public void processPayment(double amount) {
        // Actual payment gateway integration code would go here
        System.out.println("Payment processed successfully: " + amount);
    }
}