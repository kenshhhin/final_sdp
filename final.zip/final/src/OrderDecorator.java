interface OrderDecorator {
    double decorate(double originalPrice);
}
