// Adaptee (Kaspi Bank)
public class KaspiBank implements BankCard {
    private String cardNumber;
    private String cardHolderName;
    private String expirationDate;
    private int cvv;

    // Constructor, getters, and setters

    // Implement BankCard interface methods
    @Override
    public String getCardNumber() {
        return cardNumber;
    }

    @Override
    public String getCardHolderName() {
        return cardHolderName;
    }

    @Override
    public String getExpirationDate() {
        return expirationDate;
    }

    @Override
    public int getCVV() {
        return cvv;
    }
}
