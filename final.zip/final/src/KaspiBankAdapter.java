// Adapter
public class KaspiBankAdapter implements BankCard, PaymentGateway {
    // ... (implementation details)

    // Implement PaymentGateway interface method
    @Override
    public void processPayment(double amount) {
        // Implement the payment processing logic using Kaspi Bank API
        System.out.println("Payment processed using Kaspi Bank.");
        // Additional logic based on the Kaspi Bank API
    }

    @Override
    public String getCardNumber() {
        return null;
    }

    @Override
    public String getCardHolderName() {
        return null;
    }

    @Override
    public String getExpirationDate() {
        return null;
    }

    @Override
    public int getCVV() {
        return 0;
    }
}