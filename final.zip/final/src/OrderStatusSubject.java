import java.util.ArrayList;
import java.util.List;

class OrderStatusSubject implements OrderSubject {
    private List<OrderObserver> observers = new ArrayList<>();

    @Override
    public void addObserver(OrderObserver observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(OrderObserver observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers(String orderStatus) {
        for (OrderObserver observer : observers) {
            observer.update(orderStatus);
        }
    }
}
