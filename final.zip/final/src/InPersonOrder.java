class InPersonOrder implements Order {
    private String orderId;

    public InPersonOrder(String orderId) {
        this.orderId = orderId;
    }

    @Override
    public void placeOrder() {
        System.out.println("In-Person Order " + orderId + " placed successfully!");
    }

    @Override
    public void setDecorator(OrderDecorator orderDecorator) {

    }
}