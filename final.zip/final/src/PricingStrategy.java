interface PricingStrategy {
    double calculatePrice(double originalPrice);
}