public interface BankCard {
    String getCardNumber();
    String getCardHolderName();
    String getExpirationDate();
    int getCVV();
}