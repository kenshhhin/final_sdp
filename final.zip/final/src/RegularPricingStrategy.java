
class RegularPricingStrategy implements PricingStrategy {
    @Override
    public double calculatePrice(double originalPrice) {
        return originalPrice; // no change for regular pricing
    }
}